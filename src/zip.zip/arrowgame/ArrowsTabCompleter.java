package arrowgame;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.util.StringUtil;

public class ArrowsTabCompleter implements TabCompleter {

	private static final String[] COMMANDS = { "restart", "start", "scoreboard", "stop" };
	@Override
	public List<String> onTabComplete(CommandSender arg0, Command arg1, String arg2, String[] arg3) {
        final List<String> completions = new ArrayList<>();
        for(String s : COMMANDS) {
        	if(arg3.length==0 || s.contains(arg3[0])) {
        		completions.add(s);
        	}
        }

        return completions;
	}

}
