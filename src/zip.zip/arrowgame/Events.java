package arrowgame;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Lightable;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;

public class Events implements Listener {
	@EventHandler
	void onArrowLand(ProjectileHitEvent e) {
		if (e.getEntityType().equals(EntityType.ARROW)) {
			Arrow arrow = (Arrow) e.getEntity();
			if (arrow.getShooter() instanceof Player && e.getHitBlock() != null) {
				Player shooter = (Player) arrow.getShooter();
				Block b = e.getHitBlock();
				Material m = b.getBlockData().getMaterial();
				Bukkit.getScheduler().scheduleSyncDelayedTask(Main.plugin, new Runnable() {

					@Override
					public void run() {

						int score = 0;
						boolean hasHit = false;
						switch (m) {
						case TARGET:
							hasHit = true;
							break;
						case DECORATED_POT:
							score += 8;
							hasHit = true;
							break;
						case REDSTONE_LAMP:
							Lightable l = (Lightable) b.getBlockData();
							if (l.isLit()) {
								arrow.remove();
								score += 20;
								hasHit = true;
							}
							break;
						default:
							break;
						}
						if (hasHit == true) {
							for (int i = 1; i <= 2; i++) {
								Block c = b.getWorld().getBlockAt(b.getLocation().subtract(0, i, 1));
								switch (c.getBlockData().getMaterial()) {
								case YELLOW_WOOL:
								case COPPER_BLOCK:
									score += 2;
									break;
								case IRON_BLOCK:
								case BLUE_WOOL:
									score += 5;
									break;
								case GOLD_BLOCK:
								case RED_WOOL:
									score += 10;
									break;
								default:
									score += 1;
								}
							}

							int multiplier = Math.abs(b.getZ() + 194) / 10;
							multiplier = Math.max(1, multiplier);
							multiplier = Math.min(500, multiplier);
							score = score * multiplier;
							CommandArrows.addScore(shooter, score, b.getLocation());

						}

					}
				}, 5L);
			}
		}

	}
}